jpbf_cv1 <- function(x, y, h, lambda, maxit = 30, tol = 10^{-6}) {
  n <- nrow(x)
  p <- ncol(x)
  out <- .C("jpbf_cv", n = n, p = p, h = as.double(h), lambda = lambda, x = as.double(c(t(x))), 
            y = as.double(y), maxit = as.integer(maxit), tol = as.double(tol), phi_loo = double(n*p))
  phi_loo <- matrix(out$phi_loo, ncol = p, byrow = TRUE)
  loocv <- mean(((y - mean(y)) - apply(phi_loo, 1, sum))^2)
  return(loocv)
}

jpbf.cv <- function(formula, data, hs, lambdas, scale = TRUE, maxit = 30, tol = 10^{-5}, ncpus = 1) {
  ncpus <- min(detectCores(), ncpus)
  par_grid <- as.matrix(expand.grid(hs, lambdas))
  colnames(par_grid) <- c("h", "lambda")
  stopifnot(inherits(formula, "formula"))
  if (missing(data)) {
    df <- lm(formula, method = "model.frame")
  } else {
    stopifnot(inherits(data, "data.frame"))
    df <- lm(formula, data = data, method = "model.frame")
  }
  mod.mat <- model.matrix(formula, data = df)[, -1]
  if (scale) {
    bars <- apply(mod.mat, 2, mean)
    sds <- apply(mod.mat, 2, sd)
    x.mat <- scale(mod.mat, center = TRUE, scale = TRUE)
  } else {
    x.mat <- mod.mat
  }
  y <- model.response(df)
  mccv.out <- c(mcmapply(jpbf_cv1, h = par_grid[, 1], lambda = par_grid[, 2], 
                         MoreArgs = list(x = x.mat, y = y, maxit = maxit, tol = tol), mc.cores = ncpus))
  names(mccv.out) <- NULL  
  par.cv <- par_grid[which.min(mccv.out), ]
  return(list(CVscore = mccv.out, CVpars = par.cv))
}