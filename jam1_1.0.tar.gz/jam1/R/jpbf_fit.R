jpbf.fit <- function(formula, data, h, lambda, scale = TRUE, maxit = 30, tol = 10^{-5}) {
  stopifnot(inherits(formula, "formula"))
  if (missing(data)) {
    df <- lm(formula, method = "model.frame")
  } else {
    stopifnot(inherits(data, "data.frame"))
    df <- lm(formula, data = data, method = "model.frame")
  }
  mod.mat <- model.matrix(formula, data = df)[, -1]
  if (scale) {
    bars <- apply(mod.mat, 2, mean)
    sds <- apply(mod.mat, 2, sd)
    x.mat <- scale(mod.mat, center = TRUE, scale = TRUE)
  } else {
    x.mat <- mod.mat
  }
  y <- model.response(df)
  n <- nrow(x.mat)
  p <- ncol(x.mat)
  Cout <- .C("jpbf", n = n, p = p, h = as.double(h), lambda = as.double(lambda), 
             x = as.double(c(t(x.mat))), y = as.double(y), alpha_hat = as.double(0), 
             phi_hat = double(n*p), WRMS_c = double(n*p), WRMS_l = double(n*p), 
             WRMS_r = double(n*p), maxit = as.integer(maxit), tol = as.double(tol))
  phi_hat.mat <- matrix(Cout$phi_hat, ncol = p, byrow = TRUE)
  if (scale) {
    out <- list(PHI_hat = phi_hat.mat, alpha_hat = Cout$alpha_hat, h = h, lambda = lambda, 
                formula = formula, data = data, scale = scale, bars = bars, sds = sds)
  } else {
    out <- list(PHI_hat = phi_hat.mat, alpha_hat = Cout$alpha_hat, h = h, lambda = lambda, 
                formula = formula, data = data, scale = scale)
  }
  return(out)
}

