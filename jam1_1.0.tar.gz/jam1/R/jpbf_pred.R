jpbf.pred <- function(fitted, newdata) {
  formula <- fitted$formula
  data <- fitted$data 
  scale <- fitted$scale
  h <- as.double(fitted$h)
  lambda <- as.double(fitted$lambda)
  alpha_hat <- as.double(fitted$alpha_hat)
  phi_hat <- as.double(c(t(fitted$PHI_hat)))
  stopifnot(inherits(formula, "formula"))
  if (is.null(data)) {
    df <- lm(formula, method = "model.frame")
  } else {
    stopifnot(inherits(data, "data.frame"))
    df <- lm(formula, data = data, method = "model.frame")
  }
  mod.mat <- model.matrix(formula, data = df)[, -1]
  if (scale) {
    bars <- apply(mod.mat, 2, mean)
    sds <- apply(mod.mat, 2, sd)
    x.mat <- scale(mod.mat, center = TRUE, scale = TRUE)
  } else {
    x.mat <- mod.mat
  }
  y <- model.response(df)
  n <- nrow(x.mat)
  p <- ncol(x.mat)
  stopifnot(inherits(newdata, "data.frame"))
  x_new <- model.matrix(delete.response(terms(formula)), data = newdata)[, -1]
  Cout <- .C("jpbf_pred", n = n, p = p, h = h, lambda = lambda, x = as.double(c(t(x.mat))), 
            y = as.double(y), alpha_hat = alpha_hat, phi_hat = phi_hat, n_new = nrow(x_new),
            x_new = as.double(t(x_new)), phi_new_hat = double(nrow(x_new) * p), 
            y_new_hat = double(nrow(x_new)))
  PHI_pred <- matrix(Cout$phi_new_hat, ncol = p, byrow = TRUE)
  y_pred <- Cout$y_new_hat
  return(list(PHI_pred = PHI_pred, y_pred = y_pred))
}

