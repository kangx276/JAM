#include <math.h>
#include <stdlib.h>
#include <R.h>
#include <Rmath.h>

double ker(double x) {
  double out;
  out = 0.0;
  if (fabs(x) <= 1.0) {
    out = 0.75 * (1.0 - pow(x, 2));
  }
  return(out);
}

double min(int n, double *x) {
  int i;
  double out;

  out = x[0];
  for (i = 1; i < n; i++) {
    if (x[i] < out) {
      out = x[i];
    }
  }
  return out;
}

double max(int n, double *x) {
  int i;
  double out;

  out = x[0];
  for (i = 1; i < n; i++) {
    if (x[i] > out) {
      out = x[i];
    }
  }
  return out;
}

void jpreg1(int *n_in, int *ngrid_in, double *h_in, double *lambda_in, double *x1_grid, double *x, double *y, double *ahat_c, double *ahat_l, double *ahat_r,
	    double *wrms_c, double *wrms_l, double *wrms_r, double *fhat) {
  int n = n_in[0];
  int ngrid = ngrid_in[0];
  double h = h_in[0];
  double lambda = lambda_in[0];

  double const small_number = pow(10, -8);
  
  int i, igrid, nobs, i_dx_min;
  double x1_s, dx, temp, ttemp, aal0, aal1, aal2, aar0, aar1, aar2, aac0, aac1, aac2, sy_l, sxy_l, sy_r, sxy_r, sy_c, sxy_c, det_l, det_r, det_c, left, right, central;
  double syy_l, syy_r, syy_c, slope_l, slope_r, slope_c, xmin, xmax, dx_min, dxdx;

  /* boundary points */

  xmin = min(n, x);
  xmax = max(n, x);


  for (igrid = 0; igrid < ngrid; igrid++) {
    x1_s = x1_grid[igrid];
    nobs = 0;
    aal0 = 0.0;
    aal1 = 0.0;
    aal2 = 0.0;
    aar0 = 0.0;
    aar1 = 0.0;
    aar2 = 0.0;
    sy_l = 0.0;
    sxy_l = 0.0;
    syy_l = 0.0;
    sy_r = 0.0;
    sxy_r = 0.0;
    syy_r = 0.0;
    for (i = 0; i < n; i++) {
      dx = x[i] - x1_s;
      if (fabs(dx) <= h) {
	nobs = nobs + 1;
	temp = ker(dx/h);
	ttemp = y[i] * temp;
	if (dx >= 0) {
	  aar0 = aar0 + temp;
	  aar1 = aar1 + dx * temp;
	  aar2 = aar2 + pow(dx, 2) * temp;
	  sy_r = sy_r + ttemp;
	  sxy_r = sxy_r + ttemp * dx;
	  syy_r = syy_r + ttemp * y[i];
	} else {
	  aal0 = aal0 + temp;
	  aal1 = aal1 + dx * temp;
	  aal2 = aal2 + pow(dx, 2) * temp;
	  sy_l = sy_l + ttemp;
	  sxy_l = sxy_l + ttemp * dx;
	  syy_l = syy_l + ttemp * y[i];
	}
      }
    }
    aac0 = aal0 + aar0;
    aac1 = aal1 + aar1;
    aac2 = aal2 + aar2;
    sy_c = sy_l + sy_r;
    sxy_c = sxy_l + sxy_r;
    syy_c = syy_l + syy_r;
    left = 0.0;
    right = 0.0;
    central = 0.0;
    slope_l = 0.0;
    slope_r = 0.0;
    slope_c = 0.0;
    wrms_l[igrid] = 0.0;
    wrms_r[igrid] = 0.0;
    wrms_c[igrid] = 0.0;
    det_l = aal0 * aal2 - aal1 * aal1;
    det_r = aar0 * aar2 - aar1 * aar1;
    det_c = aac0 * aac2 - aac1 * aac1;
    
      
    if ((fabs(det_r) > small_number) && (fabs(det_l) > small_number) && (fabs(det_c) > small_number) && (fabs(aar0) > small_number) && (fabs(aal0) > small_number)) {
      right = (aar2 * sy_r - aar1 * sxy_r)/det_r;
      slope_r = (aar0 * sxy_r - aar1 * sy_r)/det_r;
      left = (aal2 * sy_l - aal1 * sxy_l)/det_l;
      slope_l = (aal0 * sxy_l - aal1 * sy_l)/det_l;
      central = (aac2 * sy_c - aac1 * sxy_c)/det_c;
      slope_c = (aac0 * sxy_c - aac1 * sy_c)/det_c;
      wrms_l[igrid] = (syy_l + left * left * aal0 + slope_l * slope_l * aal2 - 2 * left * sy_l - 2 * slope_l * sxy_l + 2 * left * slope_l * aal1)/aal0;
      wrms_r[igrid] = (syy_r + right * right * aar0 + slope_r * slope_r * aar2 - 2 * right * sy_r - 2 * slope_r * sxy_r + 2 * right * slope_r * aar1)/aar0;
      wrms_c[igrid] = (syy_c + central * central * aac0 + slope_c * slope_c * aac2 - 2 * central * sy_c - 2 * slope_c * sxy_c + 2 * central * slope_c * aac1)/aac0;
    } else {
      if (fabs(det_c) > small_number) {
	central = (aac2 * sy_c - aac1 * sxy_c)/det_c;
	wrms_c[igrid] = 0.0; 	/* will use central estimate anyway, so no need to calculate the wrms */
      } else {
	/* extrapolate from the nearest observation */
	dx_min = fabs(x1_s - x[0]);
	i_dx_min = 0;
	for (i = 0; i < n; i++) {
	  dxdx = fabs(x1_s - x[i]);
	  if (dxdx < dx_min) {
	    dx_min = dxdx;
	    i_dx_min = i;
	  }
	}
	central = y[i_dx_min];
	wrms_c[igrid] = 0.0;
	/* Rprintf("Central LLK has a singular design matrix at %g with nobs = %d, aac0 = %g, aac1 = %g, aac2 = %g \n", x1_s, nobs, aac0, aac1, aac2); */
	/* Rprintf("Central LLK has a singular design matrix at %g\n", x1_s); */
      }
    }
    if ((fabs(x1_s - xmin) < h) || (fabs(x1_s - xmax) < h)) {
      fhat[igrid] = central;
    } else {
      if ((fabs(wrms_c[igrid] - wrms_l[igrid]) <= lambda) && (fabs(wrms_c[igrid] - wrms_r[igrid]) <= lambda)) {
	fhat[igrid] = central;
      } else {
	if (wrms_l[igrid] < wrms_r[igrid]) {
	  fhat[igrid] = left;
	} else {
	  fhat[igrid] = right;
	}
      }
    }
    ahat_c[igrid] = central;
    ahat_l[igrid] = left;
    ahat_r[igrid] = right;
  }

}

void jpbf(int *n_in, const int *p_in, double *h_in, double *lambda_in, double *x, double *y, double *alpha_hat, double *phi_hat, double *WRMS_c, double *WRMS_l, double *WRMS_r, int *maxit_in,
	  double *tol_in) {
  int n = n_in[0];
  int p = p_in[0];
  double maxit = maxit_in[0];
  double tol = tol_in[0];

  double const small_number = pow(10, -8);

  double *delta, *y_temp, *phi_prev, *x_temp, *ahat_c, *ahat_l, *ahat_r, *wrms_c, *wrms_l, *wrms_r, *fhat, *phi_temp;
  int i, j, j1, iter, delta_ind;
  double fhatbar;

  /* initialize */
  
  alpha_hat[0] = 0.0;
  for (i=0; i<n; i++) {
    alpha_hat[0] = alpha_hat[0] + y[i];
  }
  alpha_hat[0] = alpha_hat[0]/(1.0*n);

  phi_prev = (double *)malloc(n*p*sizeof(double));
  phi_temp = (double *)malloc(n * p * sizeof(double));
  for (i=0; i<n; i++) {
    for (j=0; j<p; j++) {
      phi_hat[i*p+j] = 0.0;
      phi_prev[i*p+j] = phi_hat[i*p+j];
      phi_temp[i*p+j] = 0.0;
    }
  }

  /* iterate */

  delta = (double *)malloc(p*sizeof(double));
  for (j=0; j<p; j++) {
    delta[j] = 100.0;
  }

  delta_ind = 0;
  for (j=0; j<p; j++) {
    if(delta[j] >= small_number) {
      delta_ind = 1;
    }
  }

  iter = 0;
  y_temp = (double *)malloc(n * sizeof(double));
  x_temp = (double *)malloc(n * sizeof(double));
  ahat_c = (double *)malloc(n * sizeof(double));
  ahat_l = (double *)malloc(n * sizeof(double));
  ahat_r = (double *)malloc(n * sizeof(double));
  wrms_c = (double *)malloc(n * sizeof(double));
  wrms_l = (double *)malloc(n * sizeof(double));
  wrms_r = (double *)malloc(n * sizeof(double));
  fhat = (double *)malloc(n * sizeof(double));

  while ((delta_ind==1) && (iter<maxit)) {
    for (j=0; j<p; j++) { 	/* columnwise smoothing */

      for (i=0; i<n; i++) {	/* update residuals */
	y_temp[i] = y[i] - alpha_hat[0];
	x_temp[i] = x[i*p + j];
	for (j1=0; j1<p; j1++) {
	  if (j1 != j) {
	    /* y_temp[i] = y_temp[i] - phi_hat[i*p+j1]; fresh start */ 
	    y_temp[i] = y_temp[i] - phi_temp[i*p+j1]; /* restart */
	  }
	}
      }	/* end updating residuals */

      /* smooth along the j-th variable */
      
      jpreg1(n_in, n_in, h_in, lambda_in, x_temp, x_temp, y_temp, ahat_c, ahat_l, ahat_r, wrms_c, wrms_l, wrms_r, fhat);

      /* centering the column */

      fhatbar = 0.0;
      for (i = 0; i < n; i++) {
	fhatbar = fhatbar + fhat[i];
      }
      fhatbar = fhatbar/(1.0 * n);


      for (i=0; i<n; i++) {
	phi_temp[i*p + j] = fhat[i] - fhatbar;
	WRMS_c[i*p + j] = wrms_c[i];
	WRMS_l[i*p + j] = wrms_l[i];
	WRMS_r[i*p + j] = wrms_r[i];
      }

    } /* end of column-wise smoothing */

    /* stopping criterion */

    iter = iter + 1;

    for (j=0; j<p; j++) {
      delta[j] = 0.0;
      for (i=0; i<n; i++) {
	delta[j] = delta[j] + pow(fabs(phi_temp[i*p+j] - phi_prev[i*p+j]), 2);
      }
      delta[j] = delta[j]/(1.0 * n);
    }

    delta_ind = 0;
    for (j=0; j<p; j++) {
      if(delta[j] >= tol) {
	delta_ind = 1;
      }
    }

    for (j=0; j<p; j++) {
      for (i=0; i<n; i++) {
	phi_prev[i*p+j] = phi_temp[i*p+j];
	phi_hat[i*p+j] = phi_temp[i*p+j];
      }
    }

  }
    
  /* if (iter==maxit) { */
  /*   Rprintf("Exceeds max iterations.\n"); */
  /*   for (j=0; j<p; j++) { */
  /*     Rprintf("delta[%d]=%g\n", j+1, delta[j]); */
  /*   } */
  /* } */

  free(delta);
  free(phi_prev);
  free(phi_temp);
  free(y_temp);
  free(x_temp);
  free(ahat_c);
  free(ahat_l);
  free(ahat_r);
  free(wrms_c);
  free(wrms_l);
  free(wrms_r);
  free(fhat);
  
}

void jpbf_pred(int *n_in, const int *p_in, double *h_in, double *lambda_in, double *x, double *y, double *alpha_hat, double *phi_hat, int *n_new_in, double *x_new, double *phi_new_hat,
	       double *y_new_hat) {
  int n = n_in[0];
  int p = p_in[0];
  double h = h_in[0];
  double lambda = lambda_in[0];
  int n_new = n_new_in[0];

  double const small_number = pow(10, -8);
  
  double *pr, *xmins, *xmaxs, *xmm;
  int i, j, j1, i_new, i_dx_min;
  double x_temp, aal0, aal1, aal2, aar0, aar1, aar2, aac0, aac1, aac2, sy_l, sxy_l, syy_l, sy_r, sxy_r, syy_r, sy_c, sxy_c, syy_c, dx, temp, ttemp, left, right, central, det_l, det_r;
  double det_c, wrms_l_temp, wrms_r_temp, wrms_c_temp, slope_l, slope_r, slope_c, fhat_temp, dx_min, dxdx;

  /* boundary points for each xj */

  xmins = (double *)malloc(p * sizeof(double));
  xmaxs = (double *)malloc(p * sizeof(double));
  xmm = (double *)malloc(n * sizeof(double));
  for (j = 0; j < p; j++) {
    for (i = 0; i < n; i++) {
      xmm[i] = x[i * p + j];
    }
    xmins[j] = min(n, xmm);
    xmaxs[j] = max(n, xmm);
  }

 

  pr = (double *)malloc(n * sizeof(double));

  for (j = 0; j < p; j++) {
    
    /* construct partial residuals */

    for (i = 0; i < n; i++) {
      pr[i] = y[i] - alpha_hat[0];
      for (j1 = 0; j1 < p; j1++) {
	if (j1 != j) {
	  pr[i] = pr[i] - phi_hat[i*p+j1];
	}
      }
    }

    for (i_new = 0; i_new < n_new; i_new++) {

      /* kernel smoothing at new data points */

      x_temp = x_new[i_new*p+j]; 
    
      aal0 = 0.0;
      aal1 = 0.0;
      aal2 = 0.0;
      aar0 = 0.0;
      aar1 = 0.0;
      aar2 = 0.0;
      sy_l = 0.0;
      sxy_l = 0.0;
      syy_l = 0.0;
      sy_r = 0.0;
      sxy_r = 0.0;
      syy_r = 0.0;
      for (i = 0; i < n; i++) {
	dx = x[i*p+j] - x_temp;
	if (fabs(dx) <= h) {
	  temp = ker(dx/h);
	  ttemp = pr[i] * temp;
	  if (dx >= 0) {
	    aar0 = aar0 + temp;
	    aar1 = aar1 + dx * temp;
	    aar2 = aar2 + pow(dx, 2) * temp;
	    sy_r = sy_r + ttemp;
	    sxy_r = sxy_r + ttemp * dx;
	    syy_r = syy_r + ttemp * pr[i];
	  } else {
	    aal0 = aal0 + temp;
	    aal1 = aal1 + dx * temp;
	    aal2 = aal2 + pow(dx, 2) * temp;
	    sy_l = sy_l + ttemp;
	    sxy_l = sxy_l + ttemp * dx;
	    syy_l = syy_l + ttemp * pr[i];
	  }
	}
      }

      aac0 = aal0 + aar0;
      aac1 = aal1 + aar1;
      aac2 = aal2 + aar2;
      sy_c = sy_l + sy_r;
      sxy_c = sxy_l + sxy_r;
      syy_c = syy_l + syy_r;
      left = 0.0;
      right = 0.0;
      central = 0.0;
      slope_l = 0.0;
      slope_r = 0.0;
      slope_c = 0.0;
      wrms_l_temp = 0.0;
      wrms_r_temp = 0.0;
      wrms_c_temp = 0.0;
      det_l = aal0 * aal2 - aal1 * aal1;
      det_r = aar0 * aar2 - aar1 * aar1;
      det_c = aac0 * aac2 - aac1 * aac1;
      if ((fabs(det_r) > small_number) && (fabs(det_l) > small_number) && (fabs(det_c) > small_number) && (fabs(aar0) > small_number) && (fabs(aal0) > small_number)) {
	right = (aar2 * sy_r - aar1 * sxy_r)/det_r;
	slope_r = (aar0 * sxy_r - aar1 * sy_r)/det_r;
	left = (aal2 * sy_l - aal1 * sxy_l)/det_l;
	slope_l = (aal0 * sxy_l - aal1 * sy_l)/det_l;
	central = (aac2 * sy_c - aac1 * sxy_c)/det_c;
	slope_c = (aac0 * sxy_c - aac1 * sy_c)/det_c;
	wrms_l_temp = (syy_l + left * left * aal0 + slope_l * slope_l * aal2 - 2 * left * sy_l - 2 * slope_l * sxy_l + 2 * left * slope_l * aal1)/aal0;
	wrms_r_temp = (syy_r + right * right * aar0 + slope_r * slope_r * aar2 - 2 * right * sy_r - 2 * slope_r * sxy_r + 2 * right * slope_r * aar1)/aar0;
	wrms_c_temp = (syy_c + central * central * aac0 + slope_c * slope_c * aac2 - 2 * central * sy_c - 2 * slope_c * sxy_c + 2 * central * slope_c * aac1)/aac0;
      } else {
	if (fabs(det_c) > small_number) {
	  central = (aac2 * sy_c - aac1 * sxy_c)/det_c;
	  wrms_c_temp = 0.0; 	/* will use central estimate anyway, so no need to calculate the wrms */
	} else {
	  /* extrapolate from the nearest observations */
	  dx_min = fabs(x[0*p + j] - x_temp);
	  i_dx_min = 0;
	  for (i = 0; i < n; i++) {
	    dxdx = fabs(x[i*p + j] - x_temp);
	    if (dxdx < dx_min) {
	      dx_min = dxdx;
	      i_dx_min = i;
	    }
	  }
	  central = pr[i_dx_min];
	  wrms_c_temp = 0.0;
	  /* error("Prediction: Central LLK has a singular design matrix at %g\n", x_temp); */
	  /* Rprintf("Prediction: Central LLK has a singular design matrix in the %d-th variate at x = %g\n", j, x_temp); */
	}
      }
      if ((fabs(x_temp - xmins[j]) < h) || (fabs(x_temp - xmaxs[j]) < h)) {
	fhat_temp = central;
      } else {
	if ((fabs(wrms_c_temp - wrms_l_temp) <= lambda) && (fabs(wrms_c_temp - wrms_r_temp) <= lambda)) {
	  fhat_temp = central;
	} else {
	  if (wrms_l_temp < wrms_r_temp) {
	    fhat_temp = left;
	  } else {
	    fhat_temp = right;
	  }
	}
      }

      phi_new_hat[i_new*p + j] = fhat_temp;

    } /* end of j-th variate prediction */

  }

  for (i_new = 0; i_new < n_new; i_new++) {
    y_new_hat[i_new] = alpha_hat[0];
    for (j = 0; j < p; j++) {
      y_new_hat[i_new] = y_new_hat[i_new] + phi_new_hat[i_new*p+j];
    }
  }

  free(pr);
  free(xmaxs);
  free(xmins);
  free(xmm);
}

void jpbf_cv(int *n_in, const int *p_in, double *h_in, double *lambda_in, double *x, double *y, int *maxit_in, double *tol_in, double *phi_loo) {
  int n = n_in[0];
  int p = p_in[0];
  
  double *x_cv, *y_cv, *phi_hat, *alpha_hat, *x_held, *y_held, *y_held_hat, *phi_held_hat, *WRMS_c, *WRMS_l, *WRMS_r;

  int i, j, i1, n_cv, n_held;

  n_held = 1;
  x_held = (double *)malloc(n_held * p * sizeof(double));
  phi_held_hat = (double *)malloc(n_held * p * sizeof(double));
  y_held = (double *)malloc(n_held * sizeof(double));
  y_held_hat = (double *)malloc(n_held * sizeof(double));

  n_cv = n - n_held;
  x_cv = (double *)malloc(n_cv * p * sizeof(double));
  y_cv = (double *)malloc(n_cv * sizeof(double));
  phi_hat = (double *)malloc(n_cv * p * sizeof(double));
  alpha_hat = (double *)malloc(1 * sizeof(double));
  WRMS_c = (double *)malloc(n_cv * p * sizeof(double));
  WRMS_l = (double *)malloc(n_cv * p * sizeof(double));
  WRMS_r = (double *)malloc(n_cv * p * sizeof(double));

  for (i = 0; i < n; i++) { 	/* hold out each observation */
    for (j = 0; j < p; j++) {
      x_held[j] = x[i*p + j];
    }
    y_held[0] = y[i];

    /* create LOO data */
    for (i1 = 0; i1 < n_cv; i1++) {
      if (i1 < i) {
	y_cv[i1] = y[i1];
	for (j = 0; j < p; j++) {
	  x_cv[i1*p + j] = x[i1*p + j];
	}
      } else {
	y_cv[i1] = y[i1 + 1];
	for (j = 0; j < p; j++) {
	  x_cv[i1*p + j] = x[(i1 + 1)*p + j];
	}
      }
    }

    /* fit to the LOO data */
    
    jpbf(&n_cv, p_in, h_in, lambda_in, x_cv, y_cv, alpha_hat, phi_hat, WRMS_c, WRMS_l, WRMS_r, maxit_in, tol_in);

    /* predict on the held-out observation */
    jpbf_pred(&n_cv, p_in, h_in, lambda_in, x_cv, y_cv, alpha_hat, phi_hat, &n_held, x_held, phi_held_hat, y_held_hat);

    /* LOO predicted phi */

    for (j = 0; j < p; j++) {
      phi_loo[i*p + j] = phi_held_hat[j];
    }

  }

  free(x_held);
  free(phi_held_hat);
  free(y_held);
  free(y_held_hat);
  free(x_cv);
  free(y_cv);
  free(phi_hat);
  free(alpha_hat);
  free(WRMS_c);
  free(WRMS_l);
  free(WRMS_r);

}
